# Punto de Venta Cafetería — App de escritorio

Este proyecto convierte el punto de venta en un programa de escritorio real (Windows, Mac o Linux), con instalador propio. No necesita internet ni GitHub para funcionar una vez instalado: todos los datos (productos, ventas, personal) se guardan en tu computadora automáticamente.

## Requisito único: Node.js

Necesitas tener [Node.js](https://nodejs.org) instalado en tu computadora (descarga la versión "LTS"). Solo se instala una vez.

## Cómo compilarlo

1. Descarga y descomprime esta carpeta en tu computadora.
2. Abre una terminal dentro de esa carpeta.
3. Ejecuta:
   ```
   npm install
   ```
   (esto descarga Electron; solo se hace una vez y puede tardar unos minutos).
4. Para **probarlo** sin generar instalador todavía:
   ```
   npm start
   ```
5. Para generar el **instalador final** para tu sistema operativo:
   ```
   npm run dist
   ```
   Esto crea una carpeta `dist/` con el instalador:
   - Windows: un archivo `.exe`
   - Mac: un archivo `.dmg`
   - Linux: un archivo `.AppImage`

6. Ejecuta ese instalador como cualquier otro programa. Quedará instalado con su propio ícono, y podrás abrirlo desde el menú de inicio / Launchpad como cualquier otra app, sin necesidad de navegador ni de GitHub.

## Los datos

Los datos (productos, ventas, personal, configuración) se guardan automáticamente dentro de la app usando el almacenamiento propio de la aplicación — no se borran al cerrar el programa ni necesitas volver a capturarlos cada vez. Igual que en la versión web, dentro de la pestaña Productos existe un botón de "Respaldo de datos" para copiar toda tu información como texto, por si algún día cambias de computadora o reinstalas.

## Actualizaciones

Cuando quieras actualizar la app con cambios nuevos (por ejemplo un ticket rediseñado o una función nueva), solo reemplaza el archivo `index.html` de esta carpeta con la versión más reciente y vuelve a correr `npm run dist`.
